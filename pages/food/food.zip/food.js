// pages/food/food.js
// 获取应用实例
const app = getApp()
const {
    config
} = require('../../utils/config')
Page({

    /**
     * 页面的初始数据
     */
    data: {
        config: config,
        fromSelect: false,
        windowHeight: 0,
        scrollHeight: 0,
        scrollHeights: 0,
        head: 0,
        banner: 0,
        shopId: 0,
        curNum: 1,
        distance: '',
        shopName: '',
        selectCount: 0,
        totalPrice: 0,
        isRefresh: false,
        currentTab: 0,
        tabList: [],
        goodsList: [],
        paramList: [],
        temporary: {},
        list: [{
            value: '0',
            checked: false,
            pic: '/static/goods.png',
            goodsname: '芝士羊角蜜',
            nr: '纯鲜果制作，果茶清爽，芝士浓郁',
            price: '399.00'
        }],
        isAllChecked: false, //全选
        minusStatus: true,
        coupon: 0,
        checkbox: 0,
        hiddenshopcark: false,
        temParamList: [],
        shopkhiddden: true,
        couponList: [],
        couponShow: true,

    },
    getCouponList() {
        let that = this;
        wx.request({
            url: `${config}/coupon/getCouponByOpenid`,
            method: 'GET',
            data: {
                shopId: this.data.shopId,
                openid: wx.getStorageSync('openid')
            },
            header: {
                'Content-Type': 'application/json'
            },
            success(res) {
                let list = res.data.data.list;
                that.setData({
                    couponList: list,
                })
            }
        });
    },

    lingqu(e) {
        let couponId = e.currentTarget.dataset.id;
        let that = this;
        wx.request({
            url: `${config}/coupon/receiveCouponByOpenid`,
            method: 'POST',
            data: {
                couponId: couponId,
                openid: wx.getStorageSync('openid')
            },
            header: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            success(res) {
                that.getCouponList();
            }
        });
    },

    gocouponList: function () {
        this.setData({
            couponShow: false
        });
    },
    goClose: function () {
        this.setData({
            couponShow: true
        })
    },


    showShop: function () {
        this.setData({
            shopkhiddden: !this.data.shopkhiddden
        })
    },

    //选择门店
      goStore: function () {
        wx.navigateTo({
          url: '../store/store',
        })
      },
    // goStore(){
    //     console.log('vvvvvvvvvv')
    //     let that = this;
    //     wx.getSetting({
    //         success: (res) => {
    //           let authSetting = res.authSetting
    //           if (authSetting['scope.userLocation']) {
    //             // 已授权
    //             wx.getLocation({
    //                 isHighAccuracy: true, // 开启地图精准定位
    //                 type: 'gcj02',
    //                 success(res) {
    //                     const latitude = res.latitude;
    //                     const longitude = res.longitude;
    //                     wx.request({
    //                         url: `${config}/shop/getShopList`,
    //                         method: 'GET',
    //                         data: {},
    //                         header: {
    //                             'Content-Type': 'application/json'
    //                         },
    //                         success(res) {
    //                             let list = res.data.data.list;
    //                             list.forEach(item => {
    //                                 let lat = item.lat;
    //                                 let lng = item.lng;
    //                                 item.distance = that.getDistances(lat, lng, latitude, longitude);
    //                             });
    //                             let newArr = list.sort((a, b) => a.distance - b.distance);
    //                             that.setData({
    //                                 shopId: newArr[0].id,
    //                                 shopName: newArr[0].name,
    //                                 distance: newArr[0].distance < 1 ? Number(newArr[0].distance * 1000).toFixed(2) + 'm' : newArr[0].distance.toFixed(2) + 'km'
    //                             })
        
    //                             that.getCates();
        
    //                             that.getCouponList();
    //                         }
    //                     });
        
    //                 },
    //             })
    //           } else {
    //             wx.showModal({
    //               title: '开启地理位置授权',
    //               content: '确认开通地理位置开始点餐吗？',
    //               success: res => {
    //                 if (res.confirm) {
    //                   wx.openSetting()
    //                 }
    //               }
    //             })
    //           }
    //         }
    //       })
        

    // },
    // 内容
    tabNav(e) {
        let currentTab = e.currentTarget.dataset.index
        this.setData({
            currentTab
        })
        this.getGoods();
    },
    handleSwiper(e) {
        let {
            current,
            source
        } = e.detail
        if (source === 'autoplay' || source === 'touch') {
            const currentTab = current
            this.setData({
                currentTab
            })
            this.getGoods();
        }
    },

    // 产品详情
    goXq: function (e) {
        if (wx.getStorageSync('phone')){
            let cateId = this.data.tabList[`${this.data.currentTab}`].id;
        if (this.data.paramList.length > 0) {
            let curParam = this.data.paramList.reverse().find(item => item.goodsId == e.currentTarget.dataset.id);

            if (curParam != undefined) {
                wx.navigateTo({
                    url: '../productxq/productxq?cateId=' + cateId + '&goodsId=' + e.currentTarget.dataset.id + '&curSelect=' + curParam.curSelect + '&shopId=' + this.data.shopId,
                })
            } else {
                wx.navigateTo({
                    url: '../productxq/productxq?cateId=' + cateId + '&goodsId=' + e.currentTarget.dataset.id + '&shopId=' + this.data.shopId,
                })
            }

        } else {
            wx.navigateTo({
                url: '../productxq/productxq?cateId=' + cateId + '&goodsId=' + e.currentTarget.dataset.id + '&shopId=' + this.data.shopId,
            })
        }
        }else{
            wx.navigateTo({
                      url: '../login/login?from=food',
                    })
        }
        


    },

    // 单选全选
    checkboxChange(e) {
        let index = e.currentTarget.dataset.index;
        let paramList = this.data.paramList;

        this.setData({
            ['paramList[' + index + '].checked']: e.detail.value[0] ? true : false
        })
        let checkedCount = 0;
        let selectCount = 0;
        let totalPrice = 0;

        paramList.forEach(item => {
            checkedCount = item.checked ? checkedCount + 1 : checkedCount;
            selectCount = item.checked ? parseInt(item.goodsCount) + selectCount : selectCount;
            totalPrice = item.checked ? totalPrice + item.price * parseInt(item.goodsCount) : totalPrice;
        })

        this.setData({
            isAllChecked: paramList.length == checkedCount ? true : false,
            selectCount,
            totalPrice
        })

    },

    // 全选单选
    allChecked() {
        let paramList = this.data.paramList;
        paramList.forEach(item => {
            item.checked = !item.checked;
        })
        this.setData({
            paramList: paramList
        })
        let selectCount = 0;
        let totalPrice = 0;
        this.data.paramList.forEach(item => {
            selectCount = item.checked ? parseInt(item.goodsCount) + selectCount : selectCount;
            totalPrice = item.checked ? totalPrice + item.price * parseInt(item.goodsCount) : totalPrice;
        })
        this.setData({
            totalPrice: totalPrice,
            selectCount: selectCount
        })

    },

    //数量增加
    addNum(e) {
        let index = e.currentTarget.dataset.index;
        console.log(e)
        console.log(index)
        let paramList = this.data.paramList;
        let goodsCount = paramList[index].goodsCount;
        let selectCount = 0;
        let totalPrice = 0;

        this.setData({
            ['paramList[' + index + '].goodsCount']: parseInt(goodsCount) + 1,
            minusStatus: false,
        })
        this.data.paramList.forEach(item => {
            selectCount = item.checked ? parseInt(item.goodsCount) + selectCount : selectCount;
            totalPrice = item.checked ? totalPrice + item.price * parseInt(item.goodsCount) : totalPrice;
        })
        this.setData({
            totalPrice:  totalPrice.toFixed(2),
            selectCount: selectCount
        })
    },

    //数量减少
    minusNum(e) {
        let index = e.currentTarget.dataset.index;
        let paramList = this.data.paramList;
        let goodsCount = parseInt(paramList[index].goodsCount);
        let selectCount = 0;
        let totalPrice = 0;
        if (goodsCount > 1) {
            goodsCount--;
        }
        var minusStatus = goodsCount <= 1 ? true : false;
        this.setData({
            ['paramList[' + index + '].goodsCount']: goodsCount,
            minusStatus: minusStatus,
        })
        this.data.paramList.forEach(item => {
            selectCount = item.checked ? parseInt(item.goodsCount) + selectCount : selectCount;
            totalPrice = item.checked ? totalPrice + item.price * parseInt(item.goodsCount) : totalPrice;
        })
        this.setData({
            totalPrice: totalPrice.toFixed(2),
            selectCount: selectCount
        })
    },

    inputGoodsCount(e) {
        let index = e.currentTarget.dataset.index;
        let selectCount = 0;
        let totalPrice = 0;

        this.setData({
            ['paramList[' + index + '].goodsCount']: e.detail.value,
        })
        this.data.paramList.forEach(item => {
            selectCount = item.checked ? parseInt(item.goodsCount) + selectCount : selectCount;
            totalPrice = item.checked ? totalPrice + item.price * parseInt(item.goodsCount) : totalPrice;
        })
        this.setData({
            totalPrice: totalPrice.toFixed(2),
            selectCount: selectCount,
        })
    },

    confirmGoodsCount(e) {
        let index = e.currentTarget.dataset.index;
        this.setData({
            ['paramList[' + index + '].goodsCount']: e.detail.value < 1 ? 1 : e.detail.value
        })
    },

    // 结算
    goSettlement: function () {
        let params = JSON.stringify(this.data.paramList);
        let selectCount = this.data.selectCount;
        let totalPrice = this.data.totalPrice;
        let shopId = this.data.shopId;
        wx.navigateTo({
            url: '../order_info/order_info?params=' + params + '&selectCount=' + selectCount + '&totalPrice=' + totalPrice + '&shopId=' + shopId,
        })
    },

    //已选购商品删除
    goTrash: function () {

        let paramList = this.data.paramList;
        let arr = [];
        for (let i = paramList.length - 1; i >= 0; i--) {
            if (paramList[i].checked) {
                paramList.splice(i, 1);
            }

        }
        arr = arr.concat(paramList);
        let selectCount = 0;
        let totalPrice = 0;
        if (arr.length > 0) {
            arr.forEach(param => {
                param.checked = true;
                selectCount += parseInt(param.goodsCount);
                totalPrice += (parseInt(param.goodsCount) * param.price);
            })
        }
        this.setData({
            paramList: arr,
            selectCount: selectCount,
            totalPrice: totalPrice.toFixed(2),
            hiddenshop: arr.length > 0 ? false : true,
            shopkhiddden: arr.length > 0 ? false : true,
            temporary: {},
            isAllChecked: true
        });
        wx.removeStorageSync('paramList');
        wx.removeStorageSync('isAllChecked');
        wx.removeStorageSync('totalPrice');
        wx.removeStorageSync('selectCount');
    },

    getCates() {
        let that = this;
        wx.request({
            url: `${config}/shopToGoods/getCates`,
            method: 'GET',
            data: {
                shopId: this.data.shopId,
            },
            header: {
                'Content-Type': 'application/json'
            },
            success(res) {
                that.setData({
                    tabList: res.data.data.list
                });
                that.getGoods();
            }
        });
    },

    getGoods() {
        let that = this;
        let cateId = this.data.tabList[`${this.data.currentTab}`].id;
        wx.request({
            url: `${config}/shopToGoods/getGoods`,
            method: 'GET',
            data: {
                shopId: this.data.shopId,
                cateId: cateId
            },
            header: {
                'Content-Type': 'application/json'
            },
            success(res) {
                that.setData({
                    goodsList: res.data.data.list
                });
            }
        });
    },

    //   getShopInfo() {
    //     let that = this;
    //     wx.request({
    //       url: `${config}/shop/getShopInfo`,
    //       method: 'GET',
    //       data: {
    //         shopId: this.data.shopId,
    //       },
    //       header: {
    //         'Content-Type': 'application/json'
    //       },
    //       success(res) {
    //         let info = res.data.data.info;
    //         that.setData({
    //           shopName: info.name,
    //         })
    //         let lat = info.lat;
    //         let lng = info.lng;
    //         wx.getLocation({
    //           isHighAccuracy: true, // 开启地图精准定位
    //           type: 'gcj02',
    //           success(res) {
    //             const latitude = res.latitude;
    //             const longitude = res.longitude;
    //             let distance = that.getDistances(lat, lng, latitude, longitude);
    //             that.setData({
    //               distance: distance < 1 ? Number(distance * 1000).toFixed(2) + 'm' : distance.toFixed(2) + 'km'
    //             })
    //           },
    //         })

    //       }
    //     });
    //   },
    getCodeShopInfo() {
        let that = this;
        wx.request({
            url: `${config}/shop/getShopInfo`,
            method: 'GET',
            data: {
                shopId: this.data.shopId,
            },
            header: {
                'Content-Type': 'application/json'
            },
            success(res) {
                let info = res.data.data.info;
                that.setData({
                    shopName: info.name,
                })
                let lat = info.lat;
                let lng = info.lng;
                wx.getLocation({
                    isHighAccuracy: true, // 开启地图精准定位
                    type: 'gcj02',
                    success(res) {
                        const latitude = res.latitude;
                        const longitude = res.longitude;
                        let distance = that.getDistances(lat, lng, latitude, longitude);
                        that.setData({
                            distance: distance < 1 ? Number(distance * 1000).toFixed(2) + 'm' : distance.toFixed(2) + 'km'
                        })
                    },
                })

            }
        });
    },

    getShopInfo() {
        let that = this;
        wx.getLocation({
            isHighAccuracy: true, // 开启地图精准定位
            type: 'gcj02',
            success(res) {
                const latitude = res.latitude;
                const longitude = res.longitude;
                wx.request({
                    url: `${config}/shop/getShopList`,
                    method: 'GET',
                    data: {},
                    header: {
                        'Content-Type': 'application/json'
                    },
                    success(res) {
                        let list = res.data.data.list;
                        list.forEach(item => {
                            let lat = item.lat;
                            let lng = item.lng;
                            item.distance = that.getDistances(lat, lng, latitude, longitude);
                        });
                        let newArr = list.sort((a, b) => a.distance - b.distance);
                        that.setData({
                            shopId: newArr[0].id,
                            shopName: newArr[0].name,
                            distance: newArr[0].distance < 1 ? Number(newArr[0].distance * 1000).toFixed(2) + 'm' : newArr[0].distance.toFixed(2) + 'km'
                        })

                        that.getCates();

                        that.getCouponList();
                    }
                });

            },
        })


    },
    getDistances(lat1, lng1, lat2, lng2) {
        let EARTH_RADIUS = 6378.137; // 地球半径
        let radLat1 = lat1 * Math.PI / 180.0; //lat1 * Math.PI / 180.0=>弧度计算
        let radLat2 = lat2 * Math.PI / 180.0;
        let a = radLat1 - radLat2;
        let b = lng1 * Math.PI / 180.0 - lng2 * Math.PI / 180.0;
        let s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b / 2), 2)));
        s = s * EARTH_RADIUS;
        s = Math.round(s * 10000) / 10000; // 输出为公里
        return s
    },


    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        var that = this;
            if (options.shopId) {
                wx.setStorageSync("shopId", options.shopId)
            }
        wx.getSystemInfo({
            success: function (res) {
                let windowHeight = (res.windowHeight * (750 / res.windowWidth));
                that.setData({
                    windowHeight: windowHeight
                })
            }
        });

        setTimeout(function (options) {
            var head = wx.createSelectorQuery();
            var banner = wx.createSelectorQuery();
            // var coupon = wx.createSelectorQuery();
            head.select('.header').boundingClientRect();
            head.exec(function (rect) {
                if (rect[0] === null) return;
                that.setData({
                    head: rect[0].height
                })
            });
            banner.select('.tab_title').boundingClientRect();
            banner.exec(function (rect) {
                if (rect[0] === null) return;
                that.setData({
                    banner: rect[0].height
                })
            });
            // coupon.select('.couponk').boundingClientRect();
            // coupon.exec(function (rect) {
            //   if (rect[0] === null) return;
            //   that.setData({
            //     coupon: rect[0].height
            //   })
            // });
        }, 500)
        setTimeout(function () {
            var headHeight = that.data.head;
            var bannerHeight = that.data.banner;
            // var couponHeight = that.data.coupon;
            wx.getSystemInfo({
                success: function (res) {
                    let scrollHeight = res.windowHeight;
                    that.setData({
                        scrollHeight: scrollHeight - headHeight - bannerHeight - 16.5,
                        scrollHeights: scrollHeight - headHeight - bannerHeight - 61.5,
                    })
                }
            })
        }, 1000)
    },
    loginIn() {
        let that = this;
        //用户按了允许授权的按钮
        wx.login({
            success(res) {
                wx.request({
                    url: `${config}/users/auth`,
                    method: 'GET',
                    data: {
                        code: res.code
                    },
                    header: {
                        'Content-Type': 'application/json'
                    },
                    success(res) {
                        let response = res.data.data.response;
                        let token = res.data.data.token;
                        let resObj = JSON.parse(response);
                        that.saveInfo(resObj.openid);
                    }
                });
                wx.setStorageSync("code", res.code)
            },
        })
    },
    saveInfo(openid) {
        let that = this;
        wx.request({
            url: `${config}/users/login`,
            method: 'GET',
            data: {
                openid
            },
            header: {
                'Content-Type': 'application/json'
            },
            success(res) {
                wx.setStorageSync("openid", openid);
            }
        });
    },
    showData() {
        // wx.showLoading({
        //     title: '获取中......',
        // })
        this.setData({
            couponShow: true
        })
        let that = this;

        if (wx.getStorageSync('orderInfo')) {
            let info = JSON.parse(wx.getStorageSync('orderInfo'));
            let arr = [];
            info.params.forEach(item => {
                let obj = {};
                obj.checked = true;
                obj.curSelect = item.specifications;
                obj.goodsCount = item.number;
                obj.goodsId = item.goodsId;
                obj.price = item.price;
                obj.url = item.url;
                obj.name = item.name;
                obj.paramIds = item.paramIds;
                arr.push(obj)
            });
            this.setData({
                isAllChecked: true,
                paramList: arr,
                shopName: info.shopName,
                selectCount: info.totalCount,
                totalPrice: info.totalPrice
            })
            wx.removeStorageSync('orderInfo')

        } else if (this.data.fromSelect) {
            let temporary = this.data.temporary;
            let paramList = this.data.paramList;

            let aaa = paramList.find(item => item.goodsId == temporary.goodsId && item.curSelect == temporary.curSelect);
            let bbb = paramList.find(item => item.goodsCount == temporary.goodsCount);
            if (aaa == undefined) {
                let params = paramList.concat(temporary).filter(item => item.goodsId != null);
                this.setData({
                    paramList: params
                })
            } else {
                if (bbb == undefined) {
                    let curIndex = paramList.findIndex(item => item.goodsId == temporary.goodsId && item.curSelect == temporary.curSelect);
                    this.setData({
                        ['paramList[' + curIndex + '].goodsCount']: temporary.goodsCount,

                    })
                }
            }
            let selectCount = 0;
            let totalPrice = 0;
            let checkedCount = 0;
            this.data.paramList.forEach(item => {
                checkedCount = item.checked ? checkedCount + 1 : checkedCount;
                selectCount += parseInt(item.goodsCount);
                totalPrice += item.price * parseInt(item.goodsCount);
            })
            this.setData({
                isAllChecked: this.data.paramList.length == checkedCount ? true : false,
                totalPrice: totalPrice.toFixed(2),
                selectCount: selectCount,
            });

        } else if (wx.getStorageSync('paramList') && wx.getStorageSync('isAllChecked') && wx.getStorageSync('totalPrice') && wx.getStorageSync('selectCount')) {
            this.setData({
                paramList: wx.getStorageSync('paramList'),
                isAllChecked: wx.getStorageSync('isAllChecked'),
                totalPrice: wx.getStorageSync('totalPrice'),
                selectCount: wx.getStorageSync('selectCount')
            })
        }


        if (this.data.paramList.length > 1) {
            wx.setStorageSync('paramList', this.data.paramList);
            wx.setStorageSync('isAllChecked', this.data.isAllChecked);
            wx.setStorageSync('totalPrice', this.data.totalPrice);
            wx.setStorageSync('selectCount', this.data.selectCount);
            this.setData({
                paramList: this.data.paramList.reverse()
            });

        }
        // wx.hideLoading()
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {
        // if (wx.getStorageSync('phone')) {
        //     if (wx.getStorageSync('shopId')) {
        //         this.setData({
        //             shopId: wx.getStorageSync('shopId')
        //         })
        //         this.getCodeShopInfo();
        //         this.getCates();
        //         this.getCouponList();
        //     } else {
        //         this.getShopInfo();
        //     }

        // } else {
        //     wx.navigateTo({
        //       url: '../login/login',
        //     })

        // }
        if (wx.getStorageSync('shopId')) {
            this.setData({
                shopId: wx.getStorageSync('shopId')
            })
            this.getCodeShopInfo();
            this.getCates();
            this.getCouponList();
        } else {
            this.getShopInfo();
        }
        this.showData();

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})